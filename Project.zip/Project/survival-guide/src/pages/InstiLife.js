import React from 'react';

const sections = [
  {
    icon: '🏠',
    title: 'Hostels',
    desc: 'Life in hostels and tips for making friends.',
    details: `The moment you step into your hostel at IIT Bombay, you’ll feel it — that buzz in the air. It’s not just a place to sleep; it becomes your home, your hangout spot, and sometimes even your battlefield (especially during mess food wars).

You’ll meet people from every corner of the country, and before you know it, strangers will turn into close friends you can’t imagine life without. Your room will become your little world — fairy lights, posters, maybe a mattress on the floor because your actual bed is covered in laundry.

Late nights will be your thing. You’ll sit on the hostel terrace at 2 AM having deep conversations about life, play LAN games till sunrise, and go on spontaneous chai walks to VM or Shack. There’ll always be something happening — antakshari in the corridor, someone’s birthday with cake on their face, or group studies that somehow turn into meme-sharing sessions.

During GC season, you'll lose your voice cheering for your hostel. You'll learn what it means to be part of a community that celebrates together, fails together, and wins together.

Hostel life will challenge you, comfort you, and give you memories you’ll talk about for the rest of your life. You won’t just live in your hostel — you’ll live because of it.`,
    images: [
      require('../Resources/Gala/I9.jpeg'),
      require('../Resources/Gaming Night 2018_files/06.jpg')
    ]
  },
  {
    icon: '🏟️',
    title: 'Gymkhana',
    details: `🏛️ Clubs, Sports, and Cultural Activities at IIT Bombay
The Students’ Gymkhana at IIT Bombay is the heart of student life on campus. Beyond being an administrative body, it plays a vital role in nurturing the diverse interests, talents, and voices of the student community. With a structured network of councils, secretaries, and elected representatives, the Gymkhana encourages students to take initiative, build leadership skills, and engage actively in institute affairs.

From vibrant cultural clubs like dance, dramatics, music, photography, and literary arts, to tech teams involved in robotics, coding, and design — there's something for everyone. The Tech, Cultural, and Sports Councils ensure students find platforms to explore their interests and push their limits.

On the sports front, IIT Bombay has world-class facilities and a strong competitive spirit. Students actively participate in inter-IIT tournaments, institute GCs, and hostel-level matches across sports like football, athletics, basketball, cricket, volleyball, and even niche ones like fencing and squash. Regular coaching, night practice sessions, and tournaments foster both fun and discipline.

The Gymkhana also facilitates dialogue around student welfare, mental health, and academic concerns, acting as a bridge between the administration and students. It oversees elections and nominations, ensuring fair representation in various student bodies. Over the years, it has evolved into a vibrant hub of creativity, excellence, and student-driven change, shaping a campus culture that's inclusive, dynamic, and deeply engaging.

Whether you're an aspiring leader, athlete, artist, or innovator — the Students’ Gymkhana ensures you’ll have the support, space, and freedom to thrive.`,
    images: [
      require('../Resources/Gymkhana.jpeg'),
      require('../Resources/Gymkhana2.webp')
    ]
  },
  {
    icon: '🎉',
    title: 'Events',
    desc: 'Major events and fests to look forward to.',
    details: `IIT Bombay is home to some of the most iconic student-run events in India — each with its own vibe and scale. Mood Indigo (MI), the annual cultural fest, is Asia’s largest college cultural festival. Held every December, it brings together top musicians, comedians, dancers, and artists from across the country (and the world!). You'll see live concerts, fashion shows, informal events, and packed auditoriums — MI is where the campus truly comes alive.

Techfest, on the other hand, is IITB’s flagship science and technology festival, and one of Asia’s largest. It's where innovation meets impact — with exhibitions, competitions, workshops, and lectures by tech giants and Nobel laureates. Whether you're into robotics, coding, or AI, Techfest has something that’ll blow your mind.

Then there’s E-Cell (Entrepreneurship Cell), a vibrant student body that fosters the startup culture on campus. From organizing India's largest B-Plan competition to hosting E-Summit and helping students connect with VCs, mentors, and founders — E-Cell is where ideas turn into action.

Together, these three — MI, Techfest, and E-Cell — shape a core part of the IITB experience, offering platforms beyond academics to explore, build, and shine.`,
    images: [
      require('../Resources/MoodI1.avif'),
      require('../Resources/MoodI2.webp')
    ]
  }
];

export default function InstiLife() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 py-14 px-2">
      <div className="max-w-4xl mx-auto p-8 bg-white/95 rounded-3xl shadow-2xl">
        <div className="mb-12 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold text-blue-900 mb-2 drop-shadow-lg">Insti Life</h1>
          <p className="text-xl md:text-2xl text-blue-700 font-medium">Experience the vibrant, quirky, and unforgettable life at IIT Bombay!</p>
        </div>
        <div className="flex flex-col gap-12">
          {sections.map(({ icon, title, desc, details, images }) => (
            <section key={title} className="bg-blue-50 rounded-2xl shadow-lg p-8 pb-10 flex flex-col items-center text-center border border-blue-200 hover:shadow-2xl transition-all duration-300">
              <div className="text-5xl mb-3">{icon}</div>
              <h2 className="text-2xl font-bold text-blue-700 mb-2 tracking-wide">{title}</h2>
              <p className="text-gray-800 text-lg mb-2">{desc}</p>
              {details && (
                <p className="text-gray-700 text-base mb-4 whitespace-pre-line leading-relaxed">{details}</p>
              )}
              {images && (
                <div className="flex gap-6 justify-center mt-8 mb-0 flex-wrap">
                  {images.map((img, idx) => (
                    <img key={idx} src={img} alt={title + ' ' + (idx+1)} className="w-64 h-64 object-cover rounded-2xl border-2 border-blue-200 shadow-md hover:scale-105 hover:shadow-xl transition-all duration-300 bg-white" />
                  ))}
                </div>
              )}
            </section>
          ))}
        </div>
      </div>
    </div>
  );
} 