import React from 'react';
import MoodleImg from '../Resources/Moodle.png';
import Moodle1Img from '../Resources/Moodle1.png';
import ASC1Img from '../Resources/ASC1.png';
import ASC2Img from '../Resources/asc2.png';
import Exasc1Img from '../Resources/Exasc1.png';
import Exasc2Img from '../Resources/Exasc2.png';

export default function IITBSystems() {
  return (
    <div className="max-w-6xl w-full mx-auto p-8 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl shadow-lg">
      <h1 className="text-5xl md:text-6xl font-extrabold text-center text-blue-900 mb-12 drop-shadow-lg">IITB Systems</h1>
      <section className="mb-14">
        <h2 className="text-4xl font-bold text-center text-blue-800 mb-6">Internal ASC</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
          <img src={ASC1Img} alt="ASC Screenshot 1" className="w-[28rem] h-72 object-cover max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
          <img src={ASC2Img} alt="ASC Screenshot 2" className="w-[28rem] h-72 object-cover max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
        </div>
        <div className="bg-white rounded-lg shadow p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold mb-4 text-blue-900 flex items-center gap-2">🧾 IIT Bombay Internal ASC Portal: Academic & Administrative Backbone</h3>
          <p className="mb-6 text-lg text-gray-800">The ASC Portal (Academic and Student Content portal) is IIT Bombay’s central system for managing all administrative and academic activities. Every student at IITB uses it extensively for daily tasks ranging from course registration to accessing old grades and academic records.</p>
          <h4 className="text-xl font-semibold mb-3 text-blue-700">🧩 Key Features and Usage</h4>
          <table className="min-w-full bg-blue-50 border border-blue-200 rounded mb-6 text-base">
            <thead>
              <tr className="bg-blue-100">
                <th className="px-4 py-3 border">Feature</th>
                <th className="px-4 py-3 border">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr><td className="px-4 py-3 border">📚 Course Registration</td><td className="px-4 py-3 border">Enroll in core/elective courses each semester and submit special approvals.</td></tr>
              <tr><td className="px-4 py-3 border">📋 Running Courses</td><td className="px-4 py-3 border">View the list of currently enrolled courses, section info, and course credits.</td></tr>
              <tr><td className="px-4 py-3 border">🕒 Timetable Access</td><td className="px-4 py-3 border">Check personalized lecture/lab schedules under My Timetable.</td></tr>
              <tr><td className="px-4 py-3 border">🧑‍🏫 Past Professors</td><td className="px-4 py-3 border">View faculty who taught you previously, along with their course offerings.</td></tr>
              <tr><td className="px-4 py-3 border">📜 Grade History</td><td className="px-4 py-3 border">Access grades of all past semesters for each registered course.</td></tr>
              <tr><td className="px-4 py-3 border">📦 Course Contents</td><td className="px-4 py-3 border">Review course outlines, curriculum structure, and evaluation schemes.</td></tr>
              <tr><td className="px-4 py-3 border">🧾 Pre-registration & Add/Drop</td><td className="px-4 py-3 border">Manage course changes during the semester (e.g., dropping electives).</td></tr>
              <tr><td className="px-4 py-3 border">🧠 Academic Calendar & Circulars</td><td className="px-4 py-3 border">Track semester milestones, holidays, and official announcements.</td></tr>
              <tr><td className="px-4 py-3 border">📈 Feedback & Attendance</td><td className="px-4 py-3 border">Give feedback for completed courses and check classroom attendance.</td></tr>
              <tr><td className="px-4 py-3 border">🎓 Scholarships/Fee Info</td><td className="px-4 py-3 border">See fee payment status, apply for scholarships, and view dues if any.</td></tr>
            </tbody>
          </table>
          <h4 className="text-xl font-semibold mb-3 text-blue-700">🧑‍💼 Why Internal ASC Matters for IITB Students</h4>
          <p className="text-lg text-gray-800">Whether you're registering for a course, downloading your timetable, or checking grades from your first year, ASC is the essential portal for day-to-day academic coordination at IIT Bombay. It also acts as a formal record-keeping system, enabling smooth communication with the academic office.</p>
        </div>
      </section>
      <section className="mb-14">
        <h2 className="text-4xl font-bold text-center text-blue-800 mb-6">External ASC</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
          <img src={Exasc1Img} alt="External ASC Screenshot 1" className="w-[28rem] h-72 object-cover max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
          <img src={Exasc2Img} alt="External ASC Screenshot 2" className="w-[28rem] h-72 object-cover max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
        </div>
        <div className="bg-white rounded-lg shadow p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold mb-4 text-blue-900 flex items-center gap-2">🏛️ IITB External ASC Portal: Your Official Academic Records & Admin Hub</h3>
          <p className="mb-6 text-lg text-gray-800">The External ASC Portal (<a href='https://portal.iitb.ac.in/asc' className='text-blue-700 underline' target='_blank' rel='noopener noreferrer'>https://portal.iitb.ac.in/asc</a>) is used for managing your official academic documentation, financial activities, and personal information. Unlike the internal ASC used for daily academic interactions, the external ASC focuses on long-term, official, and administrative tasks.</p>
          <h4 className="text-xl font-semibold mb-3 text-blue-700">🧩 Key Features and Usage</h4>
          <table className="min-w-full bg-blue-50 border border-blue-200 rounded mb-6 text-base">
            <thead>
              <tr className="bg-blue-100">
                <th className="px-4 py-3 border">Feature</th>
                <th className="px-4 py-3 border">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr><td className="px-4 py-3 border">📄 Grade Reports & SPI/CPI</td><td className="px-4 py-3 border">View semester-wise grades, SPI/CPI, and academic credit details.</td></tr>
              <tr><td className="px-4 py-3 border">📋 Transcripts & Performance Summary</td><td className="px-4 py-3 border">Download or view your official academic performance for every semester.</td></tr>
              <tr><td className="px-4 py-3 border">💳 College Fee Payment</td><td className="px-4 py-3 border">Pay semester tuition fees via PAYU/NEFT and view payment receipts.</td></tr>
              <tr><td className="px-4 py-3 border">🧾 Mess Advance Payment</td><td className="px-4 py-3 border">View & pay mess advance (SMA) through linked HMA portal.</td></tr>
              <tr><td className="px-4 py-3 border">📂 Official Forms/Requests</td><td className="px-4 py-3 border">Access forms for scholarships, bonafide certificates, bank loans, etc.</td></tr>
              <tr><td className="px-4 py-3 border">📬 Personal Information</td><td className="px-4 py-3 border">Update contact details, bank account, and Aadhaar details.</td></tr>
              <tr><td className="px-4 py-3 border">🗂️ Graduation Requirements</td><td className="px-4 py-3 border">Track credit and course completion status for degree eligibility.</td></tr>
              <tr><td className="px-4 py-3 border">🖨️ Print Forms</td><td className="px-4 py-3 border">Print registration summary, vaccine payment receipts, and no-dues status.</td></tr>
            </tbody>
          </table>
        </div>
      </section>
      <section className="mb-14">
        <h2 className="text-4xl font-bold text-center text-blue-800 mb-6">Moodle</h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
          <img src={MoodleImg} alt="Moodle Screenshot" className="w-[28rem] max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
          <img src={Moodle1Img} alt="Moodle Screenshot 2" className="w-[28rem] max-w-full rounded-xl shadow-lg border-2 border-blue-200" />
        </div>
        <div className="bg-white rounded-lg shadow p-8 max-w-4xl mx-auto">
          <h3 className="text-2xl font-bold mb-4 text-blue-900 flex items-center gap-2">🎓 IIT Bombay Moodle: Your Academic Hub</h3>
          <p className="mb-6 text-lg text-gray-800">Moodle is the official Learning Management System (LMS) at IIT Bombay, acting as a central digital platform for all academic-related interactions between students and instructors. From accessing course materials to checking grades, Moodle simplifies and organizes your academic life efficiently.</p>
          <h4 className="text-xl font-semibold mb-3 text-blue-700">🔑 Key Features and Usage</h4>
          <table className="min-w-full bg-blue-50 border border-blue-200 rounded mb-6 text-base">
            <thead>
              <tr className="bg-blue-100">
                <th className="px-4 py-3 border">Feature</th>
                <th className="px-4 py-3 border">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr><td className="px-4 py-3 border">📘 Course Access</td><td className="px-4 py-3 border">View current and past courses (e.g., CS101, BB101, CH117) sorted by semester.</td></tr>
              <tr><td className="px-4 py-3 border">📥 Study Material</td><td className="px-4 py-3 border">Download lecture slides, PDFs, and textbook chapters organized by lecture.</td></tr>
              <tr><td className="px-4 py-3 border">🧑‍🏫 Faculty Instructions</td><td className="px-4 py-3 border">Read announcements, guidelines, and detailed instructions from professors.</td></tr>
              <tr><td className="px-4 py-3 border">💡 Programs & Assignments</td><td className="px-4 py-3 border">Access and download .cpp, .py, or other programming files for practice.</td></tr>
              <tr><td className="px-4 py-3 border">📊 Grades & Progress</td><td className="px-4 py-3 border">Track your completion rate, check assignment submissions, and view grades.</td></tr>
              <tr><td className="px-4 py-3 border">🧑‍🤝‍🧑 Participants</td><td className="px-4 py-3 border">View fellow classmates and faculty involved in each course.</td></tr>
              <tr><td className="px-4 py-3 border">✅ Mark as Done</td><td className="px-4 py-3 border">Keep track of completed materials and lectures.</td></tr>
              <tr><td className="px-4 py-3 border">🔄 Course Updates</td><td className="px-4 py-3 border">Stay up to date with automatic notifications and changes.</td></tr>
            </tbody>
          </table>
          <h4 className="text-xl font-semibold mb-3 text-blue-700">🧭 Navigation Highlights</h4>
          <ul className="list-disc list-inside text-lg text-gray-800 mb-2">
            <li><strong>Dashboard:</strong> Personalized view of your courses and progress.</li>
            <li><strong>My Courses:</strong> Organized view by semester—see "In Progress", "Past", or "Starred" courses.</li>
            <li><strong>Lecture Breakdown:</strong> Each week or lecture includes slides, reading chapters, and program files (like square.cpp, emoji.cpp, etc.).</li>
            <li><strong>Responsive UI:</strong> Easy to use across devices with a clean, modern interface.</li>
          </ul>
        </div>
      </section>
    </div>
  );
} 