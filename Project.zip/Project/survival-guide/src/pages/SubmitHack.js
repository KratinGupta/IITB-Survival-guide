import React, { useState } from 'react';

export default function SubmitHack() {
  const [hack, setHack] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Thank you for submitting your hack!');
    setHack('');
  };
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 py-12 px-2">
      <div className="bg-white rounded-2xl shadow-xl p-10 max-w-2xl w-full">
        <h1 className="text-4xl font-extrabold text-center text-blue-800 mb-6 flex items-center justify-center gap-2">💡 Submit a Hack</h1>
        <form onSubmit={handleSubmit}>
          <textarea
            className="w-full p-4 border-2 border-blue-200 rounded-lg mb-6 focus:outline-none focus:ring-2 focus:ring-blue-400 text-lg resize-none bg-blue-50"
            rows={6}
            placeholder="Share your tip, trick, or hack for insti life..."
            value={hack}
            onChange={e => setHack(e.target.value)}
            required
          />
          <button
            type="submit"
            className="w-full bg-blue-700 text-white text-lg font-semibold py-3 rounded-lg hover:bg-blue-800 transition shadow"
          >
            Submit Hack
          </button>
        </form>
      </div>
    </div>
  );
} 