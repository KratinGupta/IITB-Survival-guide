import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 py-12 px-2">
      <div className="max-w-5xl mx-auto p-6 bg-white/90 rounded-2xl shadow-xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-extrabold text-blue-900 mb-3 drop-shadow-lg font-mono" style={{ fontFamily: 'Poppins, Montserrat, Arial, sans-serif' }}>Getting Started</h1>
          <p className="text-base md:text-lg text-blue-700 font-medium">Welcome to your IIT Bombay journey! Here’s everything you need to kick off your first year with confidence and excitement.</p>
        </div>
        <section className="mb-14">
          <h2 className="text-3xl font-bold text-center text-blue-700 mb-6 border-b-2 border-blue-200 pb-2">💻 Laptops to Buy</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-blue-200 rounded-lg shadow text-base">
              <thead>
                <tr className="bg-blue-100">
                  <th className="px-6 py-3 border">Budget (₹)</th>
                  <th className="px-6 py-3 border">Best Pick</th>
                  <th className="px-6 py-3 border">Sample Store & Price</th>
                  <th className="px-6 py-3 border">Why It Stands Out</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="px-4 py-2 border">30–40 k</td>
                  <td className="px-4 py-2 border font-semibold">Vivobook Go 15</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.amazon.in/ASUS-Vivobook-Laptop-Windows-E1504FA-NJ542WS/dp/B0BTWF2BQX?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>,
                    <a href="https://www.reddit.com/r/IndianGaming/comments/1it3msn/is_asus_tuf_a15_2023_worth_now/?utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Reddit</a>
                  </td>
                  <td className="px-4 py-2 border">Thin, light, Ryzen 5 option, 16GB RAM possible (<a href="https://www.asus.com/in/laptops/for-home/vivobook/vivobook-go-14-e1404f/?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">ASUS Global</a>, <a href="https://www.amazon.in/ASUS-Vivobook-Laptop-Windows-E1504FA-NJ542WS/dp/B0BTWF2BQX?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">30–40 k</td>
                  <td className="px-4 py-2 border font-semibold">HP 15 (i3‑1315U)</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.amazon.in/HP-i3-1315U-Anti-Glare-Micro-Edge-15-6-inch/dp/B0C3RF3HT3?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>,
                    <a href="https://www.flipkart.com/hp-15s-2023-intel-core-i3-13th-gen-1315u-8-gb-512-gb-ssd-windows-11-home-15-fd0019tu-thin-light-laptop/p/itmd0947fdd46b8a?utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Flipkart</a>
                  </td>
                  <td className="px-4 py-2 border">13th Gen i3, 8 GB + 512 GB SSD, FHD, MS Office included (<a href="https://www.amazon.in/HP-i3-1315U-Anti-Glare-Micro-Edge-15-6-inch/dp/B0C3RF3HT3?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>, <a href="https://www.croma.com/hp-15-fd0006tu-intel-core-i3-13th-gen-15-6-inch-8gb-512gb-windows-11-home-ms-office-2021-intel-uhd-fhd-display-natural-silver-7p6z8pa-/p/275777?srsltid=AfmBOor4YaCDven17BkouHoG6zDoVENW7J9hcqyV2fIg0wqmotl43BYT&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Croma</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">30–40 k</td>
                  <td className="px-4 py-2 border font-semibold">Lenovo IdeaPad Slim 3</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.lenovo.com/in/en/p/laptops/ideapad/ideapad-s-series/ideapad-slim-3i-gen-8-15-inch-intel/len101i0069?srsltid=AfmBOorQTBSKTeM2nUGmUxJsdx4o6rMZFt397TVaylSFy76kDdY8QnBk&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Lenovo</a>
                  </td>
                  <td className="px-4 py-2 border">Slim design, FHD, includes MS Office, good daily performance (<a href="https://www.lenovo.com/in/en/p/laptops/ideapad/ideapad-s-series/ideapad-slim-3i-gen-8-15-inch-intel/len101i0069?srsltid=AfmBOorQTBSKTeM2nUGmUxJsdx4o6rMZFt397TVaylSFy76kDdY8QnBk&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Lenovo</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">~40 k</td>
                  <td className="px-4 py-2 border font-semibold">Samsung Galaxy Book 4</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.samsung.com/in/computers/galaxy-book/galaxy-book4/buy/?srsltid=AfmBOoqVhVEd3LUx5xOYhCYILuT4D22TvEGLnVX8ja2vlOK52O6SnSI8&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Samsung us</a>,
                    <a href="https://www.flipkart.com/samsung-galaxy-book4-intel-core-5-120u-8-gb-512-gb-ssd-windows-11-home-np750xgk-ks1in-thin-light-laptop/p/itm673b4ea418a68?utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Flipkart</a>
                  </td>
                  <td className="px-4 py-2 border">Premium build, Core i5/i7 options, thin and well‑featured (<a href="https://www.samsung.com/in/computers/galaxy-book/galaxy-book4/buy/?srsltid=AfmBOoqVhVEd3LUx5xOYhCYILuT4D22TvEGLnVX8ja2vlOK52O6SnSI8&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Samsung us</a>, <a href="https://www.flipkart.com/samsung-galaxy-book4-intel-core-5-120u-8-gb-512-gb-ssd-windows-11-home-np750xgk-ks1in-thin-light-laptop/p/itm673b4ea418a68?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Flipkart</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">50–70 k</td>
                  <td className="px-4 py-2 border font-semibold">Dell Inspiron 5430</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.amazon.in/Dell-Inspiron-i5-1335U-Processor-Thunderbolt/dp/B0C2HVSHX6?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>,
                    <a href="https://www.flipkart.com/dell-inspiron-5430-core-i5-13th-gen-8-gb-512-gb-ssd-windows-11-home-in5430yxvw9m01ors1-laptop/p/itm69db2a6b985e6?cmpid=content_computer_8965229628_gmc&lid=LSTCOMGQRCGGJD2TYXHEWGC7N&marketplace=FLIPKART&pid=COMGQRCGGJD2TYXH&utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Flipkart</a>
                  </td>
                  <td className="px-4 py-2 border">13th Gen i5, 8 GB/512 GB, FHD+, Thunderbolt 4, MS Office (<a href="https://www.amazon.in/Dell-Inspiron-i5-1335U-Processor-Thunderbolt/dp/B0C2HVSHX6?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>, <a href="https://www.flipkart.com/dell-inspiron-5430-core-i5-13th-gen-8-gb-512-gb-ssd-windows-11-home-in5430yxvw9m01ors1-laptop/p/itm69db2a6b985e6?cmpid=content_computer_8965229628_gmc&lid=LSTCOMGQRCGGJD2TYXHEWGC7N&marketplace=FLIPKART&pid=COMGQRCGGJD2TYXH&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Flipkart</a>, <a href="https://www.croma.com/dell-inspiron-5430-intel-core-i5-13th-gen-14-inch-8gb-1tb-windows-11-ms-office-2021-intel-iris-xe-fhd-plus-display-platinum-silver-in5430nh6kjm01ors1-/p/274958?srsltid=AfmBOoprCqmCUi562FVqzl1n_yoyLP_j9sW7rhLjDiBSChZJ6g2EXt1I&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Croma</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">50–70 k</td>
                  <td className="px-4 py-2 border font-semibold">ThinkPad E14 G5</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.lenovo.com/in/en/p/laptops/thinkpad/thinkpade/thinkpad-e14-gen-5-%2814-inch-intel%29/len101t0064?srsltid=AfmBOorb0c3wqVZRKCmUpCatE8PyOBssQE0newXdG_gJIxmo-77orrZg&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Lenovo (Gen 5)</a>,
                    <a href="https://www.lenovo.com/in/en/p/laptops/thinkpad/thinkpade/thinkpad-e14-gen-5-14-inch-intel/len101t0064?srsltid=AfmBOoqZ0ieGuT0GGNY7iPNyibn6wzzrvojDPv_jeHdtURlOU8SK4FMq&utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Lenovo (Gen 6)</a>
                  </td>
                  <td className="px-4 py-2 border">Durable business-class build, Intel 13th Gen options (<a href="https://www.lenovo.com/in/en/p/laptops/thinkpad/thinkpade/thinkpad-e14-gen-5-14-inch-intel/len101t0064?srsltid=AfmBOoqZ0ieGuT0GGNY7iPNyibn6wzzrvojDPv_jeHdtURlOU8SK4FMq&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Lenovo (Gen 6)</a>, <a href="https://www.lenovo.com/in/en/p/laptops/thinkpad/thinkpade/thinkpad-e14-gen-5-%2814-inch-intel%29/len101t0064?srsltid=AfmBOorb0c3wqVZRKCmUpCatE8PyOBssQE0newXdG_gJIxmo-77orrZg&utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Lenovo (Gen 5)</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">~90 k</td>
                  <td className="px-4 py-2 border font-semibold">MacBook Air M2 13″</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.amazon.in/2022-Apple-MacBook-Laptop-chip/dp/B0DLHFM2XL?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>,
                    <a href="https://idestiny.in/product/macbook-air-m2/?utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">iDestiny</a>
                  </td>
                  <td className="px-4 py-2 border">Apple M2, excellent battery life, seamless macOS (<a href="https://www.amazon.in/2022-Apple-MacBook-Laptop-chip/dp/B0DLHFM2XL?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>, <a href="https://idestiny.in/product/macbook-air-m2/?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">iDestiny</a>)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">60–72 k</td>
                  <td className="px-4 py-2 border font-semibold">ASUS TUF Gaming A15</td>
                  <td className="px-4 py-2 border">
                    <a href="https://www.amazon.in/ASUS-15-6-inch-GeForce-Graphite-FA506NCR-HN054W/dp/B0D5DFR78J?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>,
                    <a href="https://www.flipkart.com/asus-tuf-gaming-a15-ryzen-5-hexa-core-amd-r5-4600h-8-gb-1-tb-ssd-windows-11-home-4-gb-graphics-nvidia-geforce-gtx-1650-144-hz-fa506ihrz-hn112w-laptop/p/itm69c384a52cfb3?utm_source=chatgpt.com" className="text-blue-600 underline ml-1" target="_blank" rel="noopener noreferrer">Flipkart</a>
                  </td>
                  <td className="px-4 py-2 border">Gaming-capable GPU, sturdy build, great value for the budget (<a href="https://www.amazon.in/ASUS-15-6-inch-GeForce-Graphite-FA506NCR-HN054W/dp/B0D5DFR78J?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Amazon India</a>, <a href="https://www.flipkart.com/asus-tuf-gaming-a15-ryzen-5-hexa-core-amd-r5-4600h-8-gb-1-tb-ssd-windows-11-home-4-gb-graphics-nvidia-geforce-gtx-1650-144-hz-fa506ihrz-hn112w-laptop/p/itm69c384a52cfb3?utm_source=chatgpt.com" className="text-blue-600 underline" target="_blank" rel="noopener noreferrer">Flipkart</a>)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
        <section className="mb-14">
          <h2 className="text-3xl font-bold text-center text-blue-700 mb-6 border-b-2 border-blue-200 pb-2">🎒 Packing List</h2>
          <ul className="list-disc list-inside text-lg text-gray-800 bg-blue-50 rounded-xl p-6 shadow mb-2 divide-y divide-blue-100">
            <li className="mb-4 pb-4">📄 <strong>Documents:</strong> Fee Receipts, Certificates, Filled-in Forms (Form A-E), ID cards, JEE Hall Ticket, Passport-sized & Stamp-sized photos (12+, 10+), 3-5 photocopies of all documents</li>
            <li className="mb-4 pb-4">🧴 <strong>Toiletries:</strong> Toothbrush, Toothpaste, Tongue Scraper, Soap, Facewash, Shampoo, Hair Oil, Comb, Perfumes, Vaseline, Earbuds, Nail Trimmer, Washing Powder/Soap, Clothes Brush, Dish wash bar/liquid, Dish Sponge/Scrubber</li>
            <li className="mb-4 pb-4">💊 <strong>Medical Equipment:</strong> Moov/Volini, General Medicines, First Aid kit (available in hostel)</li>
            <li className="mb-4 pb-4">👕 <strong>Clothes & Footwear:</strong> Towels (2-4), Bedsheets (4-5), Pillow covers (2-3), Shirts (4+), Trousers (5+), T-Shirts (4+), Night Pants (2+), Boxers (3+), Sports Dress (1-2), Under Garments (5+ pairs), Hand Kerchiefs (2+), Waist Belt (1+), Quilt (1-2), Hoody (1-2), Thermal wear (1-2 pairs), Table Cover (1-2), Flip flops (1 pair), Sandals (1 pair), Socks (2+ pairs), Sports Shoes (1 pair), Casual Shoes, Formal Shoes</li>
            <li className="mb-4 pb-4">🔌 <strong>Electronics:</strong> Mobile, Charger, Laptop & Charger</li>
          </ul>
        </section>
        <section className="mb-10">
          <h2 className="text-3xl font-bold text-center text-blue-700 mb-6 border-b-2 border-blue-200 pb-2">🎉 Freshers’ Week</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-blue-200 rounded-lg shadow text-base">
              <thead>
                <tr className="bg-blue-100">
                  <th className="px-6 py-3 border">Day</th>
                  <th className="px-6 py-3 border">Date</th>
                  <th className="px-6 py-3 border">Time</th>
                  <th className="px-6 py-3 border">Venue</th>
                  <th className="px-6 py-3 border">Activities / Details</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={4}>Day 1<br/>Monday</td>
                  <td className="px-4 py-2 border" rowSpan={4}>21st July 2025</td>
                  <td className="px-4 py-2 border">08:30–09:00 am</td>
                  <td className="px-4 py-2 border">Convocation Hall</td>
                  <td className="px-4 py-2 border">Student reporting; parents seated at LHC (film on IITB played, live telecast in LHC)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">09:00–12:35 pm</td>
                  <td className="px-4 py-2 border">Convocation Hall</td>
                  <td className="px-4 py-2 border">Welcome & addresses by Director, Deans, Faculty, CMO, Library, SWC; Gender Cell, PwD Cell, SC/ST Cell, SWC, InstiApp (students only)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">2:15–5:30 pm</td>
                  <td className="px-4 py-2 border">Departments / Convocation Hall</td>
                  <td className="px-4 py-2 border">ISMP Mentors direct students to departments for course registration; Parent’s orientation (Convocation Hall)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">6:00–8:30 pm</td>
                  <td className="px-4 py-2 border">Convocation Hall / Hostels</td>
                  <td className="px-4 py-2 border">Scholarship & Financial Aid orientation (students only); Meet ISMP mentors at hostels; Dinner with Institute functionaries</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={3}>Day 2<br/>Tuesday</td>
                  <td className="px-4 py-2 border" rowSpan={3}>22nd July 2025</td>
                  <td className="px-4 py-2 border">9:30 am–5:30 pm</td>
                  <td className="px-4 py-2 border">VMCC / LA 201, 202 / Departments</td>
                  <td className="px-4 py-2 border">Biometric validation, medical record check, ID card data capture, English proficiency test, document verification, department-wise orientations</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">6:00–7:30 pm</td>
                  <td className="px-4 py-2 border">LA 001, 002, 201, 202 / Convocation Hall</td>
                  <td className="px-4 py-2 border">Technical orientation (ASC); Address by student representatives; Dinner with Institute functionaries</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">8:30 pm onwards</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">Dinner with Institute functionaries</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={2}>Day 3<br/>Wednesday</td>
                  <td className="px-4 py-2 border" rowSpan={2}>23rd July 2025</td>
                  <td className="px-4 py-2 border">9:30 am–5:30 pm</td>
                  <td className="px-4 py-2 border">VMCC / LA 201, 202 / Departments</td>
                  <td className="px-4 py-2 border">Repeat of Day 2 activities (biometric, medical, ID, English test, document verification, department orientations)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">8:30 pm onwards</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">Dinner with Institute functionaries</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={2}>Day 4<br/>Thursday</td>
                  <td className="px-4 py-2 border" rowSpan={2}>24th July 2025</td>
                  <td className="px-4 py-2 border">10:00 am–1:00 pm</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">NCC/NSS/NSO/SWC workshops</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">2:00–5:00 pm</td>
                  <td className="px-4 py-2 border">Auditoriums (VMCC, CSE, LA 001)</td>
                  <td className="px-4 py-2 border">ENTHUSE</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={2}>Day 5<br/>Friday</td>
                  <td className="px-4 py-2 border" rowSpan={2}>25th July 2025</td>
                  <td className="px-4 py-2 border">10:00 am–12:30 pm</td>
                  <td className="px-4 py-2 border">Departments</td>
                  <td className="px-4 py-2 border">Faculty Advisors and ISMP Coordinators meet</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">2:30–5:30 pm</td>
                  <td className="px-4 py-2 border">Labs</td>
                  <td className="px-4 py-2 border">Lab visit</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border" rowSpan={2}>Day 6<br/>Saturday</td>
                  <td className="px-4 py-2 border" rowSpan={2}>26th July 2025</td>
                  <td className="px-4 py-2 border">10:00 am–12:30 pm</td>
                  <td className="px-4 py-2 border">Gymkhana</td>
                  <td className="px-4 py-2 border">Tour to gymkhana facilities</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">2:30–5:30 pm</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">Free time (Orientation ends)</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">28th July 2025</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border">—</td>
                  <td className="px-4 py-2 border font-semibold">Course instruction begins</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-6 text-center text-blue-900 font-medium text-lg"><strong>Note:</strong> Students are advised to collect their Student Identity Card as per the schedule announced by Security Section, IIT Bombay. Any changes in the above schedule will be notified accordingly.</p>
        </section>
      </div>
    </div>
  );
} 