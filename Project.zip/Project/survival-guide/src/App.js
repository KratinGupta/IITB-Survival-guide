import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './pages/Home';
import IITBSystems from './pages/IITBSystems';
import InstiLife from './pages/InstiLife';
import AskSenior from './pages/AskSenior';
import SubmitHack from './pages/SubmitHack';
import './App.css';

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/iitb-systems" element={<IITBSystems />} />
          <Route path="/insti-life" element={<InstiLife />} />
          <Route path="/ask-senior" element={<AskSenior />} />
          <Route path="/submit-hack" element={<SubmitHack />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
