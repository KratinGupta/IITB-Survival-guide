import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import logoIITb from './Resources/logoIITb.png';

const navLinks = [
  { to: '/', label: 'Home' },
  // { to: '/mentors', label: 'Meet Your Mentors' },
  { to: '/iitb-systems', label: 'IITB Systems' },
  { to: '/insti-life', label: 'Insti Life' },
  { to: '/ask-senior', label: 'Ask a Senior' },
  { to: '/submit-hack', label: 'Submit a Hack' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <nav className="bg-blue-700 text-white shadow">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <img src={logoIITb} alt="IITB Logo" className="h-8 w-8 object-contain" />
          <span className="text-lg font-bold tracking-wide">Survival Guide</span>
        </div>
        <button className="md:hidden" onClick={() => setOpen(!open)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <div className={`flex-col md:flex md:flex-row md:items-center w-full md:w-auto ${open ? 'flex' : 'hidden'}`}>
          {navLinks.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `block px-3 py-2 rounded hover:bg-blue-800 transition md:mx-2 ${isActive ? 'bg-blue-900' : ''}`
              }
              onClick={() => setOpen(false)}
              end={link.to === '/'}
            >
              {link.label}
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
} 